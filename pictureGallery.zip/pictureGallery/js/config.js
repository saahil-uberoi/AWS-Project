window._config = {
    cognito: {
        region: "us-east-1",
        userPoolId: "us-east-1_xXtMpRhG2",
        clientId: "7uhrmii1e87ldijan3gh23o7k9"
      }
}